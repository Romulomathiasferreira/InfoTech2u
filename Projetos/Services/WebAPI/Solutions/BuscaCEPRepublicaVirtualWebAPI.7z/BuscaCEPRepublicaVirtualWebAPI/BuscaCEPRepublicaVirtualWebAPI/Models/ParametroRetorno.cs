﻿namespace BuscaCEPRepublicaVirtualWebAPI.Models
{
    public class ParametroRetorno
    {
        public string Estado { get; set; }
        public string Cidade { get; set; }
        public string Bairro { get; set; }
        public string TipoLogradouro { get; set; }
        public string Logradouro { get; set; }
        public string Resultado { get; set; }
        public string ResultadoTexto { get; set; }
    }
}