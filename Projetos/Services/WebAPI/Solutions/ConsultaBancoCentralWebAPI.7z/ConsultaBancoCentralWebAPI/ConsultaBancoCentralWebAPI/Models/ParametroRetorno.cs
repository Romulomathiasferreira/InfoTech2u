﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConsultaBancoCentralWebAPI.Models
{
    public class ParametroRetorno
    {
        public string ValorCotacao { get; set; }

    }
}